/**
 * QingTaoCampus 全功能测试脚本 v2 — 基于实际路由审查
 * 只读/不动代码 — 纯黑盒API测试
 */

const BASE = 'http://localhost:3000';

let adminToken = '';
let userToken = '';
let user3Token = ''; // 用于测试社交互动
let adminRefreshToken = '';

interface TestCase {
  name: string;
  pass: boolean;
  detail: string;
}
interface Module { name: string; tests: TestCase[] }
const results: Module[] = [];
let cur: string = '';

function mod(name: string) { cur = name; results.push({ name, tests: [] }); console.log(`\n${'═'.repeat(60)}\n  ${name}\n${'═'.repeat(60)}`); }
function ok(name: string, d = '') { results[results.length-1].tests.push({name, pass: true, detail: d}); console.log(`  ✅ ${name}${d ? ': ' + d : ''}`); }
function fail(name: string, d = '') { results[results.length-1].tests.push({name, pass: false, detail: d}); console.log(`  ❌ ${name}${d ? ': ' + d : ''}`); }
function chk(name: string, cond: boolean, d = '') { cond ? ok(name, d) : fail(name, d); return cond; }

// ============================================================
async function loginAs(username: string, password: string) {
  const c = await fetch(`${BASE}/api/captcha/generate`);
  const cd = await c.json() as any;
  const texts = cd.data.svg.match(/>([^<]+)<\/text>/g) || [];
  const ans = texts.map((t: string) => t.replace(/[><\/text]/g, '')).join('');
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, captchaId: cd.data.captchaId, captchaAnswer: ans })
  });
  return await r.json() as any;
}

async function authd(method: string, path: string, token: string, body?: any) {
  const opts: any = { method, headers: { 'Authorization': `Bearer ${token}` } };
  if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  return await fetch(`${BASE}${path}`, opts);
}

// ============================================================
// 1. 认证系统
// ============================================================
async function test_01_auth() {
  mod('1. 认证系统 (Auth)');

  // 验证码
  const captcha = await (await fetch(`${BASE}/api/captcha/generate`)).json() as any;
  chk('GET /api/captcha/generate 返回200', captcha.code === 200, `code=${captcha.code}`);
  chk('验证码含 captchaId', !!captcha.data?.captchaId);
  chk('验证码含 svg', !!captcha.data?.svg);

  // 登录缺少验证码 → 401
  const r1 = await (await fetch(`${BASE}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'wrong' })
  })).json() as any;
  chk('缺少captcha → 401', r1.code === 401, r1.message);

  // 登录密码错误 → 401
  const c2 = await (await fetch(`${BASE}/api/captcha/generate`)).json() as any;
  const ans2 = extractCaptcha(c2.data.svg);
  const r2 = await (await fetch(`${BASE}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'wrong', captchaId: c2.data.captchaId, captchaAnswer: ans2 })
  })).json() as any;
  chk('错误密码 → 401', r2.code === 401, r2.message);

  // admin 登录
  const al = await loginAs('admin', '123456');
  chk('admin登录成功', al.code === 200, `role=${al.data?.user?.role}`);
  adminToken = al.data?.token || '';
  adminRefreshToken = al.data?.refreshToken || '';
  chk('admin返回token', !!adminToken);
  chk('admin返回refreshToken', !!adminRefreshToken);
  chk('admin role=admin', al.data?.user?.role === 'admin');

  // 普通用户登录 (zhangsan)
  const ul = await loginAs('zhangsan', '123456');
  chk('普通用户登录成功', ul.code === 200, `username=${ul.data?.user?.username}`);
  userToken = ul.data?.token || '';
  chk('普通用户role=user', ul.data?.user?.role === 'user');

  // 第三个用户登录 (lisi) for 社交测试
  const u3l = await loginAs('lisi', '123456');
  chk('lisi登录成功', u3l.code === 200);
  user3Token = u3l.data?.token || '';

  // Refresh Token
  const rr = await (await fetch(`${BASE}/api/auth/refresh`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken: adminRefreshToken })
  })).json() as any;
  chk('Token刷新 → 200', rr.code === 200, `code=${rr.code}`);

  // 无效 Refresh Token
  const ir = await (await fetch(`${BASE}/api/auth/refresh`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken: 'invalid.token.here' })
  })).json() as any;
  chk('无效refreshToken → 401', ir.code === 401);

  // getMe
  const me = await (await fetch(`${BASE}/api/auth/me`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /api/auth/me → 200', me.code === 200);
  chk('getMe返回当前用户', me.data?.username === 'zhangsan');

  // 注册-重复用户名
  const rc = await (await fetch(`${BASE}/api/captcha/generate`)).json() as any;
  const rans = extractCaptcha(rc.data.svg);
  const reg = await (await fetch(`${BASE}/api/auth/register`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'zhangsan', password: '123456', captchaId: rc.data.captchaId, captchaAnswer: rans })
  })).json() as any;
  chk('重复用户名 → 400', reg.code === 400, reg.message);

  // 注册-用户名过短
  const reg2 = await (await fetch(`${BASE}/api/auth/register`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'a', password: '123456', captchaId: rc.data.captchaId, captchaAnswer: rans })
  })).json() as any;
  chk('用户名过短 → 400', reg2.code === 400);

  // 注册-含特殊字符
  const reg3 = await (await fetch(`${BASE}/api/auth/register`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: '<script>', password: '123456', captchaId: rc.data.captchaId, captchaAnswer: rans })
  })).json() as any;
  chk('特殊字符用户名 → 400', reg3.code === 400);

  // 忘记密码-未绑定邮箱
  const fp = await (await fetch(`${BASE}/api/auth/forgot-password`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'zhangsan', email: 'none@test.com' })
  })).json() as any;
  chk('忘记密码(无邮箱) → 400', fp.code === 400, fp.message);
}

// ============================================================
// 2. 分类 & 首页
// ============================================================
async function test_02_categories() {
  mod('2. 分类 & 首页');

  const cat = await (await fetch(`${BASE}/api/categories`)).json() as any;
  chk('GET /api/categories → 200', cat.code === 200, `code=${cat.code}`);
  chk('分类列表非空', Array.isArray(cat.data) && cat.data.length > 0, `count=${cat.data?.length}`);

  const banners = await (await fetch(`${BASE}/api/banners`)).json() as any;
  chk('GET /api/banners → 200', banners.code === 200);
  chk('轮播图列表非空', banners.data?.length > 0, `count=${banners.data?.length}`);
}

// ============================================================
// 3. 商品模块
// ============================================================
async function test_03_goods() {
  mod('3. 商品 (Goods / Cart / Favorite)');

  // 商品列表
  const list = await (await fetch(`${BASE}/api/goods`)).json() as any;
  chk('GET /api/goods → 200', list.code === 200);
  chk('商品列表有数据', list.data?.list?.length > 0, `count=${list.data?.list?.length}`);
  const gId = list.data?.list?.[0]?.id;
  
  // 筛选
  const f1 = await (await fetch(`${BASE}/api/goods?listType=sale&campus=kexue&sort=newest`)).json() as any;
  chk('筛选 listType=sale', f1.code === 200);
  const f2 = await (await fetch(`${BASE}/api/goods?listType=buy`)).json() as any;
  chk('筛选 listType=buy', f2.code === 200);

  // 商品详情
  const detail = await (await fetch(`${BASE}/api/goods/${gId}`)).json() as any;
  chk('GET /api/goods/:id → 200', detail.code === 200);
  chk('详情含title', !!detail.data?.title);
  chk('详情含user关联', !!detail.data?.user);
  chk('详情含category关联', !!detail.data?.category);

  // 创建商品
  const cr = await (await authd('POST', '/api/goods', userToken, {
    title: '【测试用】API测试商品' + Date.now(), description: '黑盒测试描述', price: 99, categoryId: 1, listType: 'sale', condition: 'like_new', campus: 'kexue'
  })).json() as any;
  chk('POST /api/goods → 201', cr.code === 201, `code=${cr.code}`);
  const ngId = cr.data?.id;
  chk('新商品 status=approved (发布即上架)', cr.data?.status === 'approved', `status=${cr.data?.status}`);

  // 更新商品
  const up = await (await authd('PUT', `/api/goods/${ngId}`, userToken, {
    title: '【测试用-已编辑】', price: 88
  })).json() as any;
  chk('PUT /api/goods/:id → 200', up.code === 200);
  chk('标题已更新', up.data?.title?.includes('已编辑'));

  // 非作者不能修改
  const badUp = await (await authd('PUT', `/api/goods/${ngId}`, adminToken, { title: 'hack' })).json() as any;
  chk('非作者修改 → 403', badUp.code === 403, `code=${badUp.code}`);

  // 标记已售
  const sold = await (await authd('PATCH', `/api/goods/${ngId}/sold`, userToken)).json() as any;
  chk('PATCH .../sold → 200', sold.code === 200, `code=${sold.code}`);

  // 取消已售
  const unsell = await (await authd('PATCH', `/api/goods/${ngId}/unsell`, userToken)).json() as any;
  chk('PATCH .../unsell → 200', unsell.code === 200);

  // 下架
  const off = await (await authd('PATCH', `/api/goods/${ngId}/offline`, userToken)).json() as any;
  chk('PATCH .../offline → 200', off.code === 200);

  // 重新上架
  const rel = await (await authd('PATCH', `/api/goods/${ngId}/relist`, userToken)).json() as any;
  chk('PATCH .../relist → 200', rel.code === 200, `code=${rel.code}`);

  // 购物车-添加
  const ca = await (await authd('POST', '/api/cart', userToken, { goodsId: gId })).json() as any;
  chk('POST /api/cart → 200', ca.code === 200, `code=${ca.code}`);
  if (ca.code === 400 && ca.message === '已在购物车中') ok('已在购物车(幂等)', ca.message);

  // 购物车-添加自己商品
  const caSelf = await (await authd('POST', '/api/cart', userToken, { goodsId: ngId })).json() as any;
  chk('不能加自己商品入购物车', caSelf.code === 400, caSelf.message);

  // 购物车-列表
  const cl = await (await fetch(`${BASE}/api/cart`, { headers: { 'Authorization': `Bearer ${userToken}` } })).json() as any;
  chk('GET /api/cart → 200', cl.code === 200);

  // 收藏-添加
  const fa = await (await authd('POST', '/api/favorites', userToken, { goodsId: gId })).json() as any;
  chk('POST /api/favorites → 200', fa.code === 200 || fa.code === 201, `code=${fa.code}`);

  // 收藏-检查
  const fc = await (await fetch(`${BASE}/api/favorites/check/${gId}`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /api/favorites/check/:goodsId', fc.code === 200);

  // 收藏-列表
  const fl = await (await fetch(`${BASE}/api/favorites`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /api/favorites → 200', fl.code === 200);

  // 评论商品
  const gc = await (await authd('POST', `/api/goods/${gId}/comments`, userToken, { content: '测试评论' })).json() as any;
  chk('POST /goods/:id/comments → 201', gc.code === 201, `code=${gc.code}`);
}

// ============================================================
// 4. 社区模块
// ============================================================
async function test_04_community() {
  mod('4. 社区 (Posts / LostFound / TreeHole)');

  // 帖子列表
  const pl = await (await fetch(`${BASE}/api/posts`)).json() as any;
  chk('GET /api/posts → 200', pl.code === 200);
  const postId = pl.data?.list?.[0]?.id;

  // 帖子详情
  const pd = await (await fetch(`${BASE}/api/posts/${postId}`)).json() as any;
  chk('GET /api/posts/:id → 200', pd.code === 200);
  chk('详情含作者', !!pd.data?.user);

  // 创建帖子
  const np = await (await authd('POST', '/api/posts', userToken, {
    title: '【测试帖】' + Date.now(), content: 'API测试内容'
  })).json() as any;
  chk('POST /api/posts → 201', np.code === 201, `code=${np.code}`);
  const newPostId = np.data?.id;

  // 评论帖子
  const pc = await (await authd('POST', `/api/posts/${postId}/comments`, userToken, {
    content: '测试评论'
  })).json() as any;
  chk('POST /posts/:id/comments → 201', pc.code === 201, `code=${pc.code}`);

  // 失物列表
  const lfl = await (await fetch(`${BASE}/api/lostfound`)).json() as any;
  chk('GET /api/lostfound → 200', lfl.code === 200);
  const lfId = lfl.data?.list?.[0]?.id;

  // 失物详情
  const lfd = await (await fetch(`${BASE}/api/lostfound/${lfId}`)).json() as any;
  chk('GET /api/lostfound/:id → 200', lfd.code === 200);

  // 创建失物
  const nlf = await (await authd('POST', '/api/lostfound', userToken, {
    type: 'lost', title: '【测试失物】', description: '测试', campus: 'kexue', location: '图书馆'
  })).json() as any;
  chk('POST /api/lostfound → 201', nlf.code === 201, `code=${nlf.code}`);
  const newLfId = nlf.data?.id;

  // 标记已解决
  if (newLfId) {
    const rs = await (await authd('PATCH', `/api/lostfound/${newLfId}/resolve`, userToken)).json() as any;
    chk('PATCH /lostfound/:id/resolve → 200', rs.code === 200, `code=${rs.code}`);
  }

  // 树洞
  const th = await (await fetch(`${BASE}/api/treehole`)).json() as any;
  chk('GET /api/treehole → 200', th.code === 200);
  chk('树洞列表(游客可访问)', Array.isArray(th.data?.list) || th.data !== null);

  // 创建树洞帖
  const thp = await (await authd('POST', '/api/treehole', userToken, {
    code: 'test_code', content: '匿名树洞测试'
  })).json() as any;
  chk('POST /api/treehole → 201', thp.code === 201, `code=${thp.code}`);
}

// ============================================================
// 5. 社交模块
// ============================================================
async function test_05_social() {
  mod('5. 社交 (Follow / Messages / Block / Dating)');

  // 关注 —— 需要对方用户，用 /api/users/:id/follow
  const fw = await (await authd('POST', '/api/users/4/follow', userToken)).json() as any;
  chk('POST /users/:id/follow → 200', fw.code === 200, `code=${fw.code}`);

  // 再次关注(幂等)
  const fw2 = await (await authd('POST', '/api/users/4/follow', userToken)).json() as any;
  chk('重复关注返回200', fw2.code === 200, `code=${fw2.code}`);

  // 取关
  const unf = await (await authd('DELETE', '/api/users/4/follow', userToken)).json() as any;
  chk('DELETE /users/:id/follow → 200', unf.code === 200);

  // 发送私信 — lisi (userId=4)
  const msg = await (await authd('POST', '/api/messages/4', userToken, {
    content: '【测试私信】你好！', type: 'text'
  })).json() as any;
  chk('POST /messages/:userId → 200', msg.code === 200, `code=${msg.code}`);

  // 会话列表
  const conv = await (await fetch(`${BASE}/api/messages/conversations`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /messages/conversations → 200', conv.code === 200);

  // 消息记录
  const msgList = await (await fetch(`${BASE}/api/messages/4`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /messages/:userId → 200', msgList.code === 200);

  // 未读消息数
  const unc = await (await fetch(`${BASE}/api/messages/unread-count`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /messages/unread-count → 200', unc.code === 200);

  // 拉黑
  const blk = await (await authd('POST', '/api/block/4', userToken)).json() as any;
  chk('POST /block/:userId → 200', blk.code === 200, `code=${blk.code}`);

  // 拉黑列表
  const bll = await (await fetch(`${BASE}/api/block`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /api/block → 200', bll.code === 200);

  // 取消拉黑
  const ublk = await (await authd('DELETE', '/api/block/4', userToken)).json() as any;
  chk('DELETE /block/:userId → 200', ublk.code === 200);

  // 恋爱区-获取资料
  const dp = await (await fetch(`${BASE}/api/dating/profile`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /dating/profile → 200', dp.code === 200, `code=${dp.code}`);

  // 恋爱区-创建/更新资料
  const dpu = await (await authd('POST', '/api/dating/profile', userToken, {
    nickname: '匿名测试', gender: 'male', bio: '测试恋爱区'
  })).json() as any;
  chk('POST /dating/profile → 200', dpu.code === 200, `code=${dpu.code}`);

  // 恋爱区帖子
  const dps = await (await fetch(`${BASE}/api/dating/posts`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /dating/posts → 200', dps.code === 200);

  // 恋爱区关注
  const df = await (await authd('POST', '/api/dating/5/follow', userToken)).json() as any;
  chk('POST /dating/:userId/follow → 200', df.code === 200, `code=${df.code}`);
}

// ============================================================
// 6. 校园答疑
// ============================================================
async function test_06_qa() {
  mod('6. 校园答疑 (QA)');

  // 列表
  const ql = await (await fetch(`${BASE}/api/qa`)).json() as any;
  chk('GET /api/qa → 200', ql.code === 200);

  // 按分类筛选
  const qf = await (await fetch(`${BASE}/api/qa?category=学习`)).json() as any;
  chk('GET /api/qa?category=学习 → 200', qf.code === 200);

  // 提问
  const qn = await (await authd('POST', '/api/qa', userToken, {
    title: '【测试问题】如何学习TypeScript？', content: '求学习路线', category: '学习', type: 'question'
  })).json() as any;
  chk('POST /api/qa → 201', qn.code === 201, `code=${qn.code}`);
  const qaId = qn.data?.id;

  // 问题详情
  const qd = await (await fetch(`${BASE}/api/qa/${qaId}`)).json() as any;
  chk('GET /api/qa/:id → 200', qd.code === 200);

  // 回答
  const an = await (await authd('POST', `/api/qa/${qaId}/answers`, user3Token, {
    content: '先学基础类型，再做项目练手。推荐阅读官方Handbook。'
  })).json() as any;
  chk('POST /qa/:id/answers → 201', an.code === 201, `code=${an.code}`);
  const ansId = an.data?.id;

  // 点赞
  const v = await (await authd('POST', `/api/qa/answers/${ansId}/vote`, userToken)).json() as any;
  chk('POST /qa/answers/:id/vote → 200', v.code === 200, `code=${v.code}`);

  // 采纳最佳答案 (仅提问者)
  const best = await (await authd('POST', `/api/qa/answers/${ansId}/best`, userToken)).json() as any;
  chk('POST /qa/answers/:id/best → 200', best.code === 200, `code=${best.code}`);
}

// ============================================================
// 7. 用户资料
// ============================================================
async function test_07_profile() {
  mod('7. 用户资料 (Profile)');

  // 查看他人主页
  const up = await (await fetch(`${BASE}/api/users/4`)).json() as any;
  chk('GET /users/4 (他人主页) → 200', up.code === 200);

  // 编辑资料
  const ep = await (await authd('PUT', '/api/users/profile', userToken, {
    nickname: '测试编辑_' + Date.now(), bio: 'API测试', campusArea: 'kexue'
  })).json() as any;
  chk('PUT /users/profile → 200', ep.code === 200, `code=${ep.code}`);

  // 修改密码
  const pw = await (await authd('PUT', '/api/users/password', userToken, {
    oldPassword: '123456', newPassword: '1234567'
  })).json() as any;
  chk('PUT /users/password → 200', pw.code === 200, `code=${pw.code}`);

  // 改回密码
  await authd('PUT', '/api/users/password', userToken, {
    oldPassword: '1234567', newPassword: '123456'
  });

  // 我的商品
  const mg = await (await fetch(`${BASE}/api/users/${up.data?.id || 4}/goods`)).json() as any;
  chk('GET /users/:id/goods → 200', mg.code === 200);

  // 我的帖子
  const mp = await (await fetch(`${BASE}/api/users/${up.data?.id || 4}/posts`)).json() as any;
  chk('GET /users/:id/posts → 200', mp.code === 200);

  // 粉丝/关注
  const flw = await (await fetch(`${BASE}/api/users/4/followers`)).json() as any;
  chk('GET /users/:id/followers → 200', flw.code === 200);
  const flg = await (await fetch(`${BASE}/api/users/4/following`)).json() as any;
  chk('GET /users/:id/following → 200', flg.code === 200);
}

// ============================================================
// 8. 通知
// ============================================================
async function test_08_notifications() {
  mod('8. 通知 (Notifications)');

  const nl = await (await fetch(`${BASE}/api/notifications`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('GET /api/notifications → 200', nl.code === 200);
}

// ============================================================
// 9. 管理员
// ============================================================
async function test_09_admin() {
  mod('9. 管理后台 (Admin)');

  // 普通用户被拒
  const ua = await (await fetch(`${BASE}/api/admin/stats`, {
    headers: { 'Authorization': `Bearer ${userToken}` }
  })).json() as any;
  chk('普通用户 → 403', ua.code === 403, `code=${ua.code}`);

  // 管理员-数据概览
  const ss = await (await fetch(`${BASE}/api/admin/stats`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  })).json() as any;
  chk('GET /admin/stats → 200', ss.code === 200);

  // 管理员-用户列表
  const uls = await (await fetch(`${BASE}/api/admin/users`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  })).json() as any;
  chk('GET /admin/users → 200', uls.code === 200);

  // 管理员-禁用/启用用户
  const targetUser = uls.data?.list?.[uls.data.list.length - 1]?.id;
  if (targetUser) {
    const dis = await (await authd('PATCH', `/api/admin/users/${targetUser}/status`, adminToken, { status: 'disabled' })).json() as any;
    chk('PATCH /admin/users/:id/status → 200', dis.code === 200, `code=${dis.code}`);
    
    const ena = await (await authd('PATCH', `/api/admin/users/${targetUser}/status`, adminToken, { status: 'active' })).json() as any;
    chk('重新启用用户', ena.code === 200, `code=${ena.code}`);
  }

  // 管理员-发布公告
  const ann = await (await authd('POST', '/api/admin/announcements', adminToken, {
    title: '测试公告' + Date.now(), content: 'API测试公告', priority: 1
  })).json() as any;
  chk('POST /admin/announcements → 201', ann.code === 201 || ann.code === 200, `code=${ann.code}`);

  // 管理员-举报列表
  const reps = await (await fetch(`${BASE}/api/admin/reports`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  })).json() as any;
  chk('GET /admin/reports → 200', reps.code === 200);
}

// ============================================================
// 10. 审核 & 举报
// ============================================================
async function test_10_moderation() {
  mod('10. 审核 & 内容安全');

  // 敏感词过滤
  const sw = await (await authd('POST', '/api/goods', userToken, {
    title: '代考服务', description: '代写论文', price: 1, categoryId: 1, campus: 'kexue'
  })).json() as any;
  chk('敏感词"代考" → 400拦截', sw.code === 400, sw.message);

  // 举报
  const rpt = await (await authd('POST', '/api/reports', userToken, {
    targetType: 'post', targetId: 1, reason: '垃圾广告'
  })).json() as any;
  chk('POST /api/reports → 200', rpt.code === 201 || rpt.code === 200, `code=${rpt.code}`);

  // 图片审核列表
  const img = await (await fetch(`${BASE}/api/admin/images`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  })).json() as any;
  chk('GET /admin/images → 200', img.code === 200);

  // 待审内容
  const pc2 = await (await fetch(`${BASE}/api/admin/content/pending`, {
    headers: { 'Authorization': `Bearer ${adminToken}` }
  })).json() as any;
  chk('GET /admin/content/pending → 200', pc2.code === 200);
}

// ============================================================
// 11. 边界 & 安全
// ============================================================
async function test_11_edge() {
  mod('11. 边界 & 安全');

  // 无Token访问
  const nt = await (await fetch(`${BASE}/api/goods`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'hack' })
  })).json() as any;
  chk('无Token POST → 401', nt.code === 401, `code=${nt.code}`);

  // 无效Token
  const bt = await (await fetch(`${BASE}/api/users/profile`, {
    headers: { 'Authorization': 'Bearer invalid.jwt.token' }
  })).json() as any;
  chk('无效Token → 401', bt.code === 401);

  // SQL注入
  const si = await (await fetch(`${BASE}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: "' OR 1=1 --", password: "x", captchaId: 'test', captchaAnswer: 'AAAA' })
  })).json() as any;
  chk('SQL注入被拦截', si.code === 401 || si.code === 400);

  // 超大分页
  const bp = await (await fetch(`${BASE}/api/goods?page=99999&pageSize=10000`)).json() as any;
  chk('超大分页 → 200(正常处理)', bp.code === 200);

  // 不存在资源
  const nf = await (await fetch(`${BASE}/api/goods/999999`)).json() as any;
  chk('不存在商品 → 404', nf.code === 404);

  // 不存在用户
  const nu = await (await fetch(`${BASE}/api/users/999999`)).json() as any;
  chk('不存在用户 → 404', nu.code === 404);
}

// ============================================================
// 12. 考试资料
// ============================================================
async function test_12_resources() {
  mod('12. 考试资料 (Resources)');

  const rl = await (await fetch(`${BASE}/api/resources`)).json() as any;
  chk('GET /api/resources → 200', rl.code === 200);

  const rn = await (await authd('POST', '/api/resources', userToken, {
    courseName: '高等数学', courseCode: 'MATH101', title: '期末试卷', type: 'exam', fileUrl: 'https://example.com/test.pdf', fileSize: 1024
  })).json() as any;
  chk('POST /api/resources → 201', rn.code === 201, `code=${rn.code}`);

  if (rn.data?.id) {
    const rd = await (await fetch(`${BASE}/api/resources/${rn.data.id}`)).json() as any;
    chk('GET /api/resources/:id → 200', rd.code === 200);
  }

  // 搜索考试资料
  const rs = await (await fetch(`${BASE}/api/resources?courseName=高等数学`)).json() as any;
  chk('搜索考试资料 → 200', rs.code === 200);
}

// ============================================================
// 辅助
// ============================================================
function extractCaptcha(svg: string): string {
  const texts = svg.match(/>([^<]+)<\/text>/g);
  if (!texts) return 'AAAA';
  return texts.map((t: string) => t.replace(/[><\/text]/g, '')).join('');
}

// ============================================================
// 主函数
// ============================================================
async function run() {
  console.log('🚀 QingTaoCampus 全功能测试 v2');
  console.log(`   后端: ${BASE}  |  时间: ${new Date().toLocaleString()}\n`);

  try {
    await test_01_auth();
    await test_02_categories();
    await test_03_goods();
    await test_04_community();
    await test_05_social();
    await test_06_qa();
    await test_07_profile();
    await test_08_notifications();
    await test_09_admin();
    await test_10_moderation();
    await test_11_edge();
    await test_12_resources();
  } catch (e) {
    console.error('💥 测试异常:', e instanceof Error ? e.message : e);
  }

  // 汇总
  console.log(`\n${'═'.repeat(60)}`);
  console.log('  📊 测试汇总');
  console.log(`${'═'.repeat(60)}`);

  let totalPass = 0, totalFail = 0;
  for (const m of results) {
    const p = m.tests.filter(t => t.pass).length;
    const f = m.tests.filter(t => !t.pass).length;
    totalPass += p; totalFail += f;
    const icon = f === 0 ? '✅' : '⚠️';
    console.log(`  ${icon} ${m.name}: ${p}/${p + f} 通过`);
  }
  console.log(`\n  🎯 总计: ${totalPass}/${totalPass + totalFail} (${totalFail === 0 ? '100.0' : ((totalPass / (totalPass + totalFail)) * 100).toFixed(1)}%) 通过`);

  if (totalFail > 0) {
    console.log(`\n  ❌ 失败列表:`);
    for (const m of results) {
      for (const t of m.tests) {
        if (!t.pass) console.log(`     [${m.name}] ${t.name}${t.detail ? ' — ' + t.detail : ''}`);
      }
    }
  }
}

run();
