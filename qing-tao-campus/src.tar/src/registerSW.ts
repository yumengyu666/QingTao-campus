/**
 * Service Worker 注册模块
 * 在 main.tsx 中导入: import './registerSW';
 */
export function registerSW() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/sw.js', { scope: '/' })
        .then((registration) => {
          console.log('[SW] Registered:', registration.scope);

          // 监听更新
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (!newWorker) return;

            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // 有新版本可用，提示用户刷新
                console.log('[SW] New version available — refresh to update');
                // 可以在这里触发 UI 提示
              }
            });
          });
        })
        .catch((err) => {
          console.warn('[SW] Registration failed:', err.message);
        });
    });

    // 监听 SW 控制权变更
    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });
  }
}
