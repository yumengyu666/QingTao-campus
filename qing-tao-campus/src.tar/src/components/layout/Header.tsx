import { FiArrowLeft, FiShare2, FiSearch } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import { DarkModeToggle } from '@/components/common/DarkModeToggle';
import { ThemePicker } from '@/components/theme/ThemePicker';
import { Breadcrumb } from '@/components/common/Breadcrumb';
import { useEffect } from 'react';

interface Props {
  title: string;
  showBack?: boolean;
  showBreadcrumb?: boolean;
  showSearch?: boolean;
  onShare?: () => void;
  rightAction?: React.ReactNode;
}

export function Header({
  title,
  showBack = true,
  showBreadcrumb = false,
  showSearch = false,
  onShare,
  rightAction,
}: Props) {
  const navigate = useNavigate();

  useEffect(() => {
    document.title = title ? `${title} - 轻淘` : '轻淘 - 郑州轻工业大学校园二手交易平台';
  }, [title]);

  return (
    <header className="sticky top-0 z-30 bg-white/85 dark:bg-[var(--color-card)]/85 backdrop-blur-xl border-b border-gray-100/80 dark:border-[var(--color-border)]/80 md:static md:bg-transparent md:dark:bg-transparent md:backdrop-blur-none md:border-0 md:mb-2">
      {/* Main Header Bar */}
      <div className="flex items-center justify-between h-11 px-4 md:px-0 md:h-auto md:py-0">
        <div className="w-16 flex items-center">
          {showBack && (
            <button
              onClick={() => navigate(-1)}
              className="p-1 -ml-1 md:p-0 md:flex md:items-center md:gap-1 md:text-sm md:text-indigo-500 md:hover:text-indigo-600 md:transition-colors group"
              aria-label="返回"
            >
              <FiArrowLeft className="text-xl md:text-base transition-transform group-hover:-translate-x-0.5" />
              <span className="hidden md:inline">返回</span>
            </button>
          )}
          {showSearch && (
            <button
              onClick={() => navigate('/search')}
              className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-white/10 transition-colors"
              aria-label="搜索"
            >
              <FiSearch className="text-lg md:text-base" />
            </button>
          )}
        </div>

        <h1 className="font-semibold text-base truncate max-w-[60%] md:font-bold md:text-lg">
          {title}
        </h1>

        <div className="w-16 flex justify-end items-center gap-1">
          <ThemePicker />
          <DarkModeToggle />
          {onShare && (
            <button
              onClick={onShare}
              className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-white/10 transition-colors"
              aria-label="分享"
            >
              <FiShare2 className="text-lg md:text-base" />
            </button>
          )}
          {rightAction}
        </div>
      </div>

      {/* Breadcrumb (desktop only) */}
      {showBreadcrumb && (
        <div className="hidden md:block px-0">
          <Breadcrumb />
        </div>
      )}
    </header>
  );
}
