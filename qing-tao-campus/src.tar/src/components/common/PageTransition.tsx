/**
 * PageTransition — 页面切换动画 v2.0
 * 
 * Features:
 * - 向上淡入页面，向下淡出（类似 iOS 导航 push/pop）
 * - 自动滚动到顶部
 * - 使用 framer-motion 高性能动画
 * - 尊重 prefers-reduced-motion
 * - RTL 友好（根据页面方向自动调整）
 */
import { motion } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { useEffect, useRef, useCallback, useState } from 'react';

const pageVariants = {
  initial: {
    opacity: 0,
    y: 16,
  },
  enter: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.3,
      ease: [0.16, 1, 0.3, 1], // ease-out-expo
    },
  },
  exit: {
    opacity: 0,
    y: -8,
    transition: {
      duration: 0.18,
      ease: [0.65, 0, 0.35, 1], // ease-in-out-quint
    },
  },
};

/* Reduced motion variant */
const reducedVariants = {
  initial: { opacity: 0 },
  enter: {
    opacity: 1,
    transition: { duration: 0.15 },
  },
  exit: {
    opacity: 0,
    transition: { duration: 0.1 },
  },
};

interface Props {
  children: React.ReactNode;
}

export function PageTransition({ children }: Props) {
  const location = useLocation();
  const prefersReduced = useRef(false);
  const [animDone, setAnimDone] = useState(false);

  useEffect(() => {
    setAnimDone(false);
  }, [location.pathname]);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    prefersReduced.current = mq.matches;
    const handler = (e: MediaQueryListEvent) => {
      prefersReduced.current = e.matches;
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [location.pathname]);

  const variants = prefersReduced.current ? reducedVariants : pageVariants;

  return (
    <motion.div
      key={location.pathname}
      variants={variants}
      initial="initial"
      animate="enter"
      exit="exit"
      onAnimationComplete={() => setAnimDone(true)}
      style={{ minHeight: 'inherit', transform: animDone ? 'none' : undefined }}
    >
      {children}
    </motion.div>
  );
}
