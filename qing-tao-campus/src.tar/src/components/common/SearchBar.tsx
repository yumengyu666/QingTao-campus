import { FiSearch } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

interface Props {
  placeholder?: string;
  searchType?: 'goods' | 'posts' | 'lostfound';
  className?: string;
}

export function SearchBar({
  placeholder = '搜索商品/帖子...',
  searchType,
  className = '',
}: Props) {
  const navigate = useNavigate();
  const to = searchType ? `/search?type=${searchType}` : '/search';

  return (
    <motion.button
      whileTap={{ scale: 0.985 }}
      onClick={() => navigate(to)}
      className={`w-full flex items-center gap-3 px-4 py-3 bg-white dark:bg-[var(--color-card)] border border-gray-100 dark:border-[var(--color-border)] rounded-2xl shadow-xs hover:border-indigo-200 dark:hover:border-indigo-800 hover:shadow-md active:scale-[0.98] transition-all duration-200 group ${className}`}
      aria-label={placeholder}
    >
      <FiSearch className="text-gray-400 group-hover:text-indigo-400 transition-colors flex-shrink-0" size={18} />
      <span className="text-sm text-gray-400 dark:text-gray-500 text-left flex-1">{placeholder}</span>
      <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-gray-50 dark:bg-[var(--color-card-hover)] text-[10px] text-gray-400 font-mono border border-gray-100 dark:border-[var(--color-border)]">
        ⌘K
      </kbd>
    </motion.button>
  );
}
