import { FiInbox } from 'react-icons/fi';
import { motion } from 'framer-motion';

interface Props {
  message?: string;
  description?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
  variant?: 'default' | 'compact' | 'subtle';
}

const containerVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
  },
};

const iconVariants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.5, delay: 0.1, ease: [0.175, 0.885, 0.32, 1.275] },
  },
};

export function EmptyState({
  message = '暂无数据',
  description,
  icon,
  action,
  variant = 'default',
}: Props) {
  const isCompact = variant === 'compact';
  const isSubtle = variant === 'subtle';

  const paddingY = isCompact ? 'py-8' : 'py-16 md:py-24';
  const iconSize = isCompact ? 'w-14 h-14' : 'w-20 h-20 md:w-24 md:h-24';
  const iconTextSize = isCompact ? 'text-2xl' : 'text-3xl md:text-4xl';

  if (isSubtle) {
    return (
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className={`flex flex-col items-center justify-center ${paddingY} px-4`}
      >
        <div className="text-gray-300 dark:text-gray-600 mb-3">
          {icon || <FiInbox className={iconTextSize} />}
        </div>
        <p className="text-sm text-gray-400 dark:text-gray-500">{message}</p>
        {description && (
          <p className="text-xs text-gray-350 dark:text-gray-600 mt-1 text-center max-w-xs">
            {description}
          </p>
        )}
        {action && <div className="mt-4">{action}</div>}
      </motion.div>
    );
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={`flex flex-col items-center justify-center ${paddingY} px-4`}
    >
      <motion.div
        variants={iconVariants}
        className={`${iconSize} rounded-2xl bg-gray-50 dark:bg-[var(--color-card)] border border-gray-100 dark:border-[var(--color-border)] flex items-center justify-center mb-5`}
      >
        {icon || (
          <FiInbox className={`${iconTextSize} text-gray-300 dark:text-gray-600`} />
        )}
      </motion.div>
      <p className="text-sm font-medium text-gray-500 dark:text-[var(--color-text-secondary)]">
        {message}
      </p>
      {description && (
        <p className="text-xs text-gray-400 dark:text-gray-500 mt-1.5 text-center max-w-xs leading-relaxed">
          {description}
        </p>
      )}
      {action && <div className="mt-5">{action}</div>}
    </motion.div>
  );
}
