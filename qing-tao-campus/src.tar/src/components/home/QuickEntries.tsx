import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

const entries = [
  { label: '求购专区', icon: '🔍', path: '/wanted', color: 'from-amber-400 to-orange-400', shadowColor: 'shadow-amber-500/20' },
  { label: '预约管理', icon: '📅', path: '/reservations', color: 'from-blue-400 to-cyan-400', shadowColor: 'shadow-blue-500/20' },
  { label: '物品交换', icon: '🔄', path: '/barter', color: 'from-green-400 to-emerald-400', shadowColor: 'shadow-green-500/20' },
  { label: '树洞', icon: '🌳', path: '/treehole', color: 'from-purple-400 to-pink-400', shadowColor: 'shadow-purple-500/20' },
];

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.06 },
  },
};

const item = {
  hidden: { opacity: 0, y: 12 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] },
  },
};

export function QuickEntries() {
  const navigate = useNavigate();

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="grid grid-cols-4 gap-2 px-4 py-3"
    >
      {entries.map((e) => (
        <motion.button
          key={e.label}
          variants={item}
          whileTap={{ scale: 0.92 }}
          onClick={() => navigate(e.path)}
          className="flex flex-col items-center gap-1.5 p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-[var(--color-card-hover)] transition-colors active:scale-95"
        >
          <div
            className={`w-11 h-11 rounded-xl bg-gradient-to-br ${e.color} flex items-center justify-center text-xl shadow-md ${e.shadowColor}`}
          >
            {e.icon}
          </div>
          <span className="text-xs font-medium text-gray-700 dark:text-[var(--color-text)]">
            {e.label}
          </span>
        </motion.button>
      ))}
    </motion.div>
  );
}
