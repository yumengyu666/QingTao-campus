import { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiSend, FiZap, FiTrash2, FiMessageCircle, FiHelpCircle, FiBookOpen, FiHeart, FiUsers, FiChevronLeft, FiChevronDown, FiCalendar, FiArrowLeft } from 'react-icons/fi';
import { useAgentChat, QUICK_QUESTIONS, renderMarkdown } from '@/hooks/useAgentChat';
import { apiFetch } from '@/utils/api';
import toast from 'react-hot-toast';

const PLATFORM_FEATURES = [
  { icon: FiMessageCircle, color: 'from-emerald-400 to-cyan-400', title: '二手交易', desc: '买卖闲置物品，安全便捷的校园二手市场' },
  { icon: FiUsers, color: 'from-blue-400 to-indigo-400', title: '校园广场', desc: '发帖交流、失物招领，连接每一个同学' },
  { icon: FiHelpCircle, color: 'from-amber-400 to-orange-400', title: '校园答疑', desc: '学习互助社区，提问解答分享经验' },
  { icon: FiZap, color: 'from-purple-400 to-pink-400', title: '树洞', desc: '匿名倾诉空间，自由表达真实想法' },
  { icon: FiBookOpen, color: 'from-teal-400 to-green-400', title: '考试资料', desc: '学习资源共享，历年试卷笔记' },
  { icon: FiHeart, color: 'from-rose-400 to-red-400', title: '恋爱交友', desc: '认识志同道合的朋友，真诚交友' },
];

export default function AgentPage() {
  const {
    messages, input, setInput, isLoading,
    aiMode, setAiMode, showReasoning,
    sendMessage, handleClear, toggleReasoning,
    inputRef,
  } = useAgentChat();

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(true);

  const showEmptyState = messages.length === 1 && messages[0].id === 0;
  const showQuickQs = showEmptyState;

  // ── 对话历史 ──
  const [showHistory, setShowHistory] = useState(false);
  const [sessions, setSessions] = useState<any[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(false);

  const loadSessions = useCallback(async () => {
    setLoadingSessions(true);
    try {
      const res = await apiFetch('/api/agent/sessions');
      const data = await res.json();
      if (data.code === 200) setSessions(data.data?.list || []);
    } catch {} finally { setLoadingSessions(false); }
  }, []);

  useEffect(() => {
    if (showHistory) loadSessions();
  }, [showHistory, loadSessions]);

  const handleDeleteSession = async (sessionId: string) => {
    try {
      const res = await apiFetch(`/agent/sessions/${sessionId}`, { method: 'DELETE' });
      if (res.ok) {
        setSessions((prev) => prev.filter((s: any) => s.id !== sessionId));
        toast.success('已删除');
      }
    } catch { toast.error('删除失败'); }
  };

  // Auto-scroll to bottom but respect user scroll position
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;
    const onScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setShouldAutoScroll(scrollHeight - scrollTop - clientHeight < 80);
    };
    container.addEventListener('scroll', onScroll, { passive: true });
    return () => container.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (shouldAutoScroll) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, shouldAutoScroll]);

  // Focus input on mount
  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 400);
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] md:h-[calc(100vh-5rem)] bg-gradient-to-b from-emerald-50/30 to-cyan-50/20 dark:from-gray-900 dark:to-gray-900">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-200/60 dark:border-gray-700/60 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm flex-shrink-0">
        <button
          onClick={() => window.history.back()}
          className="md:hidden w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <FiChevronLeft className="w-5 h-5 text-gray-500" />
        </button>
        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-emerald-500 flex items-center justify-center flex-shrink-0 shadow-md">
          <svg viewBox="0 0 40 40" width="26" height="26">
            <defs>
              <linearGradient id="agentGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#22d3ee" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>
            <ellipse cx="20" cy="24" rx="14" ry="13" fill="url(#agentGrad)" />
            <ellipse cx="20" cy="27" rx="9" ry="8" fill="#a7f3d0" opacity="0.6" />
            <ellipse cx="13" cy="20" rx="5" ry="6" fill="white" />
            <circle cx="14" cy="19" r="2.5" fill="#1e293b" />
            <circle cx="12" cy="18" r="1.2" fill="white" />
            <ellipse cx="27" cy="20" rx="5" ry="6" fill="white" />
            <circle cx="28" cy="19" r="2.5" fill="#1e293b" />
            <circle cx="26" cy="18" r="1.2" fill="white" />
          </svg>
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="font-semibold text-gray-900 dark:text-gray-100 text-sm">小轻助手</h2>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {aiMode === 'thinking' ? '🧠 深度思考模式' : '⚡ 快捷响应'}
          </p>
        </div>
        <button
          onClick={() => { handleClear(); toast.success('对话已清除'); }}
          className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          title="清除对话"
        >
          <FiTrash2 className="w-4 h-4 text-gray-400" />
        </button>
        <button
          onClick={() => setShowHistory(!showHistory)}
          className={`w-8 h-8 flex items-center justify-center rounded-lg transition-colors ${showHistory ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-400'}`}
          title="对话历史"
        >
          <FiCalendar className="w-4 h-4" />
        </button>
      </div>

      {/* Messages area */}
      <div ref={scrollContainerRef} className="flex-1 overflow-y-auto relative">
        {/* History sidebar */}
        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, x: -300 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -300 }}
              className="absolute left-0 top-0 bottom-0 w-[280px] sm:w-[320px] bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 z-10 flex flex-col"
            >
              <div className="flex items-center gap-2 px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                <FiCalendar className="w-4 h-4 text-gray-500" />
                <h3 className="text-sm font-semibold text-gray-900 dark:text-gray-100">对话历史</h3>
                <button onClick={() => setShowHistory(false)} className="ml-auto w-7 h-7 flex items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                  <FiChevronLeft className="w-4 h-4 text-gray-400" />
                </button>
              </div>
              <div className="flex-1 overflow-y-auto">
                {loadingSessions ? (
                  <div className="flex items-center justify-center py-10">
                    <motion.div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full" animate={{ rotate: 360 }} transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }} />
                  </div>
                ) : sessions.length === 0 ? (
                  <div className="px-4 py-10 text-center">
                    <FiMessageCircle className="w-10 h-10 text-gray-300 dark:text-gray-600 mx-auto mb-2" />
                    <p className="text-sm text-gray-400 dark:text-gray-500">暂无对话历史</p>
                    <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">和小轻对话后，会在这里显示</p>
                  </div>
                ) : (
                  <div className="p-2 space-y-1">
                    {sessions.map((session) => (
                      <div key={session.id} className="group flex items-center gap-2 px-3 py-2.5 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                        <div className="flex-1 min-w-0 cursor-pointer" onClick={() => setShowHistory(false)}>
                          <p className="text-sm text-gray-800 dark:text-gray-200 line-clamp-1">
                            {session.firstQuery}
                          </p>
                          <p className="text-[10px] text-gray-400 dark:text-gray-500 mt-0.5">
                            {session.messageCount} 条消息 · {new Date(session.lastActive).toLocaleDateString('zh-CN')}
                          </p>
                        </div>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDeleteSession(session.id); }}
                          className="w-6 h-6 flex items-center justify-center rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30 text-gray-400 hover:text-red-500 transition-all opacity-0 group-hover:opacity-100"
                        >
                          <FiTrash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Empty state */}
        {showEmptyState && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-xl mx-auto px-4 py-6"
          >
            {/* Mascot greeting */}
            <div className="text-center mb-6">
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                className="inline-block mb-3"
              >
                <svg viewBox="0 0 100 100" width="80" height="80">
                  <defs>
                    <linearGradient id="bigAgentGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#06b6d4" />
                      <stop offset="50%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#059669" />
                    </linearGradient>
                  </defs>
                  <ellipse cx="50" cy="58" rx="32" ry="28" fill="url(#bigAgentGrad)" />
                  <ellipse cx="50" cy="64" rx="20" ry="16" fill="#a7f3d0" opacity="0.35" />
                  <ellipse cx="28" cy="34" rx="10" ry="14" fill="#06b6d4" opacity="0.85" />
                  <ellipse cx="72" cy="34" rx="10" ry="14" fill="#10b981" opacity="0.85" />
                  <circle cx="50" cy="24" r="7" fill="#22d3ee" opacity="0.8" />
                  <ellipse cx="40" cy="50" rx="9" ry="11" fill="white" />
                  <circle cx="42" cy="48" r="4.5" fill="#1e293b" />
                  <circle cx="39" cy="46" r="2" fill="white" opacity="0.9" />
                  <ellipse cx="60" cy="50" rx="9" ry="11" fill="white" />
                  <circle cx="62" cy="48" r="4.5" fill="#1e293b" />
                  <circle cx="59" cy="46" r="2" fill="white" opacity="0.9" />
                </svg>
              </motion.div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-1">你好，我是小轻</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                轻淘校园平台的智能助手，随时为你解答问题
              </p>
            </div>

            {/* Feature cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-6">
              {PLATFORM_FEATURES.map((feature, i) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                  whileHover={{ scale: 1.02 }}
                  className="bg-white dark:bg-gray-800 rounded-xl p-3 border border-gray-100 dark:border-gray-700 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => sendMessage(`${feature.title}有什么功能？`)}
                >
                  <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-2`}>
                    <feature.icon className="w-4 h-4 text-white" />
                  </div>
                  <h4 className="font-semibold text-xs text-gray-900 dark:text-gray-100">{feature.title}</h4>
                  <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-0.5 line-clamp-1">{feature.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Messages list */}
        <div className="max-w-4xl mx-auto px-4 py-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}>
              {!msg.isUser && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-emerald-500 flex items-center justify-center flex-shrink-0 mr-2.5 mt-1 shadow-sm">
                  <svg viewBox="0 0 20 20" width="14" height="14">
                    <ellipse cx="10" cy="12" rx="7" ry="6.5" fill="white" opacity="0.9" />
                    <ellipse cx="7" cy="10" rx="2.5" ry="3" fill="#1e293b" opacity="0.6" />
                    <ellipse cx="13" cy="10" rx="2.5" ry="3" fill="#1e293b" opacity="0.6" />
                  </svg>
                </div>
              )}
              <div className="max-w-[75%] md:max-w-[70%]">
                {/* Reasoning */}
                {msg.reasoning && (
                  <div className="mb-1.5">
                    <button
                      onClick={() => toggleReasoning(msg.id)}
                      className="flex items-center gap-1.5 text-xs text-purple-500 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 px-2.5 py-1 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/40 transition-colors"
                    >
                      <span>🧠</span>
                      {showReasoning[msg.id] ? '收起思考过程' : '查看思考过程'}
                    </button>
                    <AnimatePresence>
                      {showReasoning[msg.id] && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                          className="overflow-hidden"
                        >
                          <div className="mt-1 px-3 py-2 bg-purple-50/80 dark:bg-purple-950/30 rounded-xl border border-purple-100 dark:border-purple-900/30 text-xs text-purple-700/80 dark:text-purple-300/80 leading-relaxed whitespace-pre-wrap max-h-56 overflow-y-auto">
                            {msg.reasoning}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* Message bubble */}
                <div
                  className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                    msg.isUser
                      ? 'bg-gradient-to-br from-emerald-500 to-cyan-500 text-white rounded-br-md shadow-sm'
                      : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-bl-md shadow-sm border border-gray-100 dark:border-gray-700'
                  }`}
                >
                  {renderMarkdown(msg.text)}
                  {/* Typing indicator */}
                  {msg.isStreaming && !msg.text && (
                    <div className="flex gap-1.5 py-1">
                      <motion.span className="w-2 h-2 rounded-full bg-gray-400" animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0 }} />
                      <motion.span className="w-2 h-2 rounded-full bg-gray-400" animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.15 }} />
                      <motion.span className="w-2 h-2 rounded-full bg-gray-400" animate={{ y: [0, -5, 0] }} transition={{ duration: 0.6, repeat: Infinity, delay: 0.3 }} />
                    </div>
                  )}
                  {msg.isStreaming && msg.text && (
                    <motion.span
                      animate={{ opacity: [1, 0.3, 1] }}
                      transition={{ duration: 0.8, repeat: Infinity }}
                      className="inline-block w-1.5 h-4 bg-emerald-500 dark:bg-emerald-400 rounded-full ml-0.5 align-middle"
                    />
                  )}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick questions */}
      {showQuickQs && (
        <div className="px-4 py-2.5 border-t border-gray-100/60 dark:border-gray-700/60 bg-white/60 dark:bg-gray-900/60 backdrop-blur-sm flex-shrink-0">
          <div className="flex flex-wrap gap-1.5 justify-center max-w-2xl mx-auto">
            {QUICK_QUESTIONS.map((q, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => sendMessage(q.label)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full text-xs text-gray-600 dark:text-gray-300 hover:border-emerald-300 dark:hover:border-emerald-600 hover:text-emerald-600 dark:hover:text-emerald-400 transition-all shadow-sm"
              >
                <span>{q.icon}</span>
                <span>{q.label}</span>
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {/* Input area */}
      <div className="px-4 py-3 border-t border-gray-200/60 dark:border-gray-700/60 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm flex-shrink-0">
        <div className="max-w-4xl mx-auto">
          {/* Mode toggle */}
          <div className="flex items-center gap-1.5 mb-2">
            <button
              onClick={() => setAiMode('quick')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                aiMode === 'quick'
                  ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <FiZap className="w-3 h-3" /> 快捷
            </button>
            <button
              onClick={() => setAiMode('thinking')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition-all ${
                aiMode === 'thinking'
                  ? 'bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 shadow-sm'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <span>🧠</span> 思考
            </button>
          </div>

          {/* Input row */}
          <div className="flex items-center gap-2">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={aiMode === 'thinking' ? '开启深度思考，问点深度问题...' : '输入你的问题...'}
              maxLength={2000}
              className="flex-1 px-4 py-2.5 bg-gray-100 dark:bg-gray-800 rounded-xl text-sm text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 outline-none focus:ring-2 focus:ring-emerald-400 dark:focus:ring-emerald-500 transition-all"
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || isLoading}
              className="w-10 h-10 flex items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-500 text-white shadow-md hover:shadow-lg disabled:opacity-40 disabled:cursor-not-allowed transition-all flex-shrink-0"
            >
              <FiSend className="w-4 h-4" />
            </motion.button>
          </div>
          <p className="text-[11px] text-gray-400 dark:text-gray-500 mt-1.5 text-center">
            {aiMode === 'thinking'
              ? '思考模式展示推理过程，回复更深入但稍慢'
              : '默认快捷响应 · 点击「思考」切换深度推理'}
          </p>
        </div>
      </div>
    </div>
  );
}
